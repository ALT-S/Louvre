<?php

namespace OC\PlatformBundle\AdvertService;

class AdvertService
{

    private $adverts;

    public function __construct()
    {
        $this->adverts = array(
            array(
                'title'   => 'Recherche développpeur Symfony',
                'id'      => 1,
                'author'  => 'Alexandre',
                'content' => 'Nous recherchons un développeur Symfony débutant sur Lyon. Blabla…',
                'date'    => new \Datetime()),
            array(
                'title'   => 'Mission de webmaster',
                'id'      => 2,
                'author'  => 'Hugo',
                'content' => 'Nous recherchons un webmaster capable de maintenir notre site internet. Blabla…',
                'date'    => new \Datetime()),
            array(
                'title'   => 'Offre de stage webdesigner',
                'id'      => 3,
                'author'  => 'Mathieu',
                'content' => 'Nous proposons un poste pour webdesigner. Blabla…',
                'date'    => new \Datetime()),
            array(
                'title'   => 'Offre pour rien faire dans la vie',
                'id'      => 4,
                'author'  => 'Thomas',
                'content' => 'Nous proposons un poste pour rien foutre ! Chouette !',
                'date'    => new \Datetime())
        );
    }

    public function getAll()
    {
        return $this->adverts;
    }

    public function getOne($id)
    {
        foreach ($this->adverts as $advert) {
            if ($advert['id'] == $id) {
                return $advert;
            }
        }

        return null;
    }

    public function getLast($max)
    {

        $adverts = array_reverse($this->adverts);

        $output = array();
        for ($i=0; $i < $max; $i++) {
            if (!isset($adverts[$i])) {
                break;
            }
            
            $output[] = $adverts[$i];
        }

        return $output;
    }
}