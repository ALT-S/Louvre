<?php

namespace OC\CoreBundle\Controller;


use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class CoreController extends Controller
{

    public function indexAction()
    {

        $adverts = $this->get('oc_platform.advert_service')->getLast(3);

        return $this->render('OCCoreBundle:Core:accueil.html.twig', array(
            'last_adverts' => $adverts
        ));
    }

    public function contactAction(Request $request)
    {

        $request->getSession()->getFlashBag()->add('notice', 'La page contact n\'est pas encore terminée !');

        return $this->redirectToRoute('oc_core_home');
    }
}